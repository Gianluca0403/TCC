import sys
import os
import subprocess
import tempfile

def executar_codigo(codigo: str) -> str:
    with tempfile.NamedTemporaryFile(mode='w+', suffix='.py', delete=False) as temp_file:
        temp_file.write(codigo)
        temp_file_path = temp_file.name

    try:
        resultado = subprocess.run(
            ['python', temp_file_path],
            capture_output=True,
            text=True,
            timeout=5
        )
        return resultado.stdout.strip()
    except Exception as e:
        return f"ERRO: {e}"
    finally:
        os.remove(temp_file_path)

# ---------------------
# ENTRADA
# ---------------------
if len(sys.argv) < 4:
    print("Uso: python comparador.py <nome_do_puzzle> <caminho_codigo_jogador> <caminho_resposta>")
    sys.exit(1)

puzzle = sys.argv[1]
caminho_codigo_jogador = sys.argv[2]
caminho_resposta = sys.argv[3]

# ---------------------
# CAMINHO DO GABARITO
# ---------------------
caminho_gabarito = os.path.join(os.path.dirname(__file__), f"gabarito_{puzzle}.txt")

if not os.path.exists(caminho_gabarito):
    print(f"Gabarito '{caminho_gabarito}' não encontrado.")
    sys.exit(1)

if not os.path.exists(caminho_codigo_jogador):
    print(f"Código do jogador '{caminho_codigo_jogador}' não encontrado.")
    sys.exit(1)

# ---------------------
# LEITURA DOS CÓDIGOS
# ---------------------
with open(caminho_gabarito, 'r', encoding='utf-8') as f:
    codigo_correto = f.read()

with open(caminho_codigo_jogador, 'r', encoding='utf-8') as f:
    codigo_jogador = f.read()

# ---------------------
# EXECUÇÃO E COMPARAÇÃO
# ---------------------
saida_correta = executar_codigo(codigo_correto)
saida_jogador = executar_codigo(codigo_jogador)

resultado = "OK" if saida_correta == saida_jogador else "ERRO"

# ---------------------
# SALVAR RESULTADO
# ---------------------
with open(caminho_resposta, 'w', encoding='utf-8') as f:
    f.write(resultado)

print("Saída correta:", saida_correta)
print("Saída jogador:", saida_jogador)
print("Resultado:", resultado)